-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: clinic_management
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `appointments`
--

DROP TABLE IF EXISTS `appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appointments` (
  `appointment_id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) DEFAULT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `appointment_date` date NOT NULL,
  `appointment_time` time NOT NULL,
  `appointment_serial` int(11) DEFAULT NULL,
  `status` enum('scheduled','completed','cancelled','no-show') DEFAULT 'scheduled',
  `payment_status` enum('pending','paid','partial','refunded') DEFAULT 'pending' COMMENT 'Payment status for the appointment',
  `payment_method` varchar(50) DEFAULT NULL COMMENT 'Payment method used (e.g., cash, card, insurance)',
  `amount_paid` decimal(10,2) DEFAULT 0.00 COMMENT 'Amount paid for this appointment',
  `payment_notes` text DEFAULT NULL COMMENT 'Additional notes about payment',
  `payment_date` datetime DEFAULT NULL COMMENT 'Date and time of payment',
  `consultation_fee` decimal(10,2) DEFAULT 0.00 COMMENT 'Consultation fee for this appointment',
  `urgency_level` enum('low','normal','high','emergency') DEFAULT 'normal' COMMENT 'Medical urgency level',
  `estimated_duration` int(11) DEFAULT 30 COMMENT 'Estimated duration in minutes',
  `diagnosis` text DEFAULT NULL COMMENT 'Medical diagnosis after consultation',
  `prescription` text DEFAULT NULL COMMENT 'Prescription notes (legacy field; see prescriptions table for new records)',
  `is_admitted` tinyint(1) DEFAULT 0 COMMENT 'Whether patient was admitted',
  `admission_notes` text DEFAULT NULL COMMENT 'Admission details',
  `admission_date` datetime DEFAULT NULL COMMENT 'Date and time of admission',
  `notes` text DEFAULT NULL,
  `symptoms` text DEFAULT NULL,
  `consultation_type` enum('general','follow-up','emergency','routine') DEFAULT 'general',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Last update timestamp',
  PRIMARY KEY (`appointment_id`),
  UNIQUE KEY `unique_doctor_timeslot` (`doctor_id`,`appointment_date`,`appointment_time`),
  KEY `patient_id` (`patient_id`),
  KEY `idx_payment_status` (`payment_status`),
  KEY `idx_urgency_level` (`urgency_level`),
  KEY `idx_is_admitted` (`is_admitted`),
  KEY `idx_updated_at` (`updated_at`),
  CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`) ON DELETE CASCADE,
  CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`doctor_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointments`
--

LOCK TABLES `appointments` WRITE;
/*!40000 ALTER TABLE `appointments` DISABLE KEYS */;
INSERT INTO `appointments` VALUES (1,1,1,'2024-01-15','09:00:00',NULL,'scheduled','pending',NULL,0.00,NULL,NULL,0.00,'normal',30,NULL,NULL,0,NULL,NULL,'Regular heart checkup',NULL,'routine','2025-11-24 12:47:08','2025-11-25 04:09:45'),(3,3,3,'2024-01-17','14:00:00',NULL,'completed','pending',NULL,0.00,NULL,NULL,0.00,'normal',30,NULL,NULL,0,NULL,NULL,'Child vaccination',NULL,'routine','2025-11-24 12:47:08','2025-11-25 04:09:45'),(5,2,1,'2025-11-26','10:00:00',NULL,'scheduled','pending',NULL,0.00,NULL,NULL,0.00,'normal',30,NULL,NULL,0,NULL,NULL,'none','pain','','2025-11-24 13:42:45','2025-11-25 04:09:45'),(6,1,2,'2025-11-25','11:00:00',NULL,'scheduled','pending',NULL,0.00,NULL,NULL,0.00,'normal',30,NULL,NULL,0,NULL,NULL,'none','pain','','2025-11-24 13:50:46','2025-11-25 04:09:45'),(7,4,2,'2025-11-25','11:30:00',NULL,'scheduled','pending',NULL,0.00,NULL,NULL,0.00,'normal',30,NULL,NULL,0,NULL,NULL,'none','pain','','2025-11-24 15:12:12','2025-11-25 04:09:45'),(8,4,4,'2025-11-25','09:00:00',NULL,'scheduled','pending',NULL,0.00,NULL,NULL,0.00,'normal',30,NULL,NULL,0,NULL,NULL,'all','pain','','2025-11-24 16:18:11','2025-11-25 04:09:45');
/*!40000 ALTER TABLE `appointments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed
